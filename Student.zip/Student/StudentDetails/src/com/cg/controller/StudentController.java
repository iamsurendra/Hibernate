package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Student;
import com.cg.exception.StudentException;
import com.cg.service.StudentService;


@Controller
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	
	@RequestMapping("/index.obj")
	public String getHomePage(Model model){
		model.addAttribute("stdList",studentService.showAllStudents());
		model.addAttribute("department",new String[]{"CSE","ECE","ME","CE","EE"});
		model.addAttribute("student",new Student());
		model.addAttribute("find",new Student());
		model.addAttribute("delete", new Student());
		model.addAttribute("list", new Student());
		return "index";
	}
	
	@RequestMapping(value="/save.obj",method=RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("student") Student student, Model model){
		student =  studentService.save(student);
		model.addAttribute("message","student with id "+student.getId()+" added successfully!");
		return "redirect:/index.obj";
	}
	
	@RequestMapping(value="/findById.obj", method=RequestMethod.POST)
	public String findById(@ModelAttribute("find") Student student, Model model)
	{
			String details = studentService.findById(student.getId()).toString();
			System.out.println(details);
			model.addAttribute("findById", details);
			return "redirect:/index.obj";
	}
	
	@RequestMapping(value="/deleteStudent.obj", method=RequestMethod.POST)
	public String deleteStudent(@ModelAttribute("delete") Student student, Model model)
	{
		System.out.println("Here1");
		String delelteMsg = studentService.delete(student.getId()).toString();
		System.out.println(student);
		model.addAttribute("deleteById", delelteMsg);
		return "redirect:/index.obj";
	}
	
	@RequestMapping(value="/displayStudent.obj")
	public String nextPage(@RequestParam String id, Model model)
	{
		Student student = studentService.findById(Integer.parseInt(id));
		model.addAttribute("student", student);
		return "nextPage";
	}
	@RequestMapping("/listall.obj")
	public String getStudentDetails(Model model){
		
				try
				{
					List<Student> list = studentService.showAllStudents();
					if (list.isEmpty()) {
					String msg = "There are no Students";
					model.addAttribute("msg", msg);
					return "myError";
				}
				// Add the attribute to the model
				model.addAttribute("list", list);
				return "listall";
				}
				catch(DataAccessException dataAccessException)
				{
					model.addAttribute("msg","Technical Problem..Please Try Later!!");
					return "myError";
				}
		
	}
	
	@RequestMapping(value = "search.obj")
	public String viewStudentDeails(@ModelAttribute("student") Student student,
			Model model) throws StudentException {
		//	boolean isValidId;
			/*try
			{
				isValidId=studentService.isValidStudentId(student.getId());
				System.out.println("isValid="+isValidId);
			}
			catch(DataAccessException dataAccessException)
			{
				model.addAttribute("msg","Technical Problem..Please Try Later!!");
				return "myError";
			}*/
		
		/*if("".equals(student.getId()))
		{
			
		
			Student stu = new Student();
			stu = studentService.findById(student.getId());
			model.addAttribute("stu", stu);
			return "search";
		
		}else{
		
			String msg = "Enter a Valid Id!!";
			model.addAttribute("msg", msg);
			return "myError";
		}*/

			String details = studentService.findById(student.getId()).toString();
			System.out.println(details);
			model.addAttribute("stu", details);
			return "search";
	}
		
}
