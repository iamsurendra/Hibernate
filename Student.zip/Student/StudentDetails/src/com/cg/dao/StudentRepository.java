package com.cg.dao;

import java.util.List;

import com.cg.entities.Student;

public interface StudentRepository {
	
	public Student save(Student student);
	public List<Student> showAllStudents();
	public Student findById(int id);
	public Student delete(int id);
	public boolean isValidStudentId(int studentId);

}
