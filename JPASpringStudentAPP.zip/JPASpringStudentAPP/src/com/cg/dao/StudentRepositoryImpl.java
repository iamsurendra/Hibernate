package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Student;

@Repository
public class StudentRepositoryImpl implements StudentRepository {

	//Below annotation is required to inject auto created entityManager from entityManagerFactory
	@PersistenceContext
	private EntityManager entityManager;

	/* (non-Javadoc)
	 * @see com.cg.dao.EmployeeRepository#save(com.cg.entities.Employee)
	 */
	@Override
	public Student save(Student student) {

		entityManager.persist(student);
		entityManager.flush();	//required to reflect changes on database
		
		return student;
	}
	/* (non-Javadoc)
	 * @see com.cg.dao.EmployeeRepository#loadAll()
	 */
	@Override
	public List<Student> loadAll() {
		TypedQuery<Student> query = 
				entityManager.createQuery("SELECT s FROM Student s",Student.class);
		return query.getResultList();
	}

	@Override
	public Student getStudentsById(int id) {
		return entityManager.find(Student.class, id);
		
	}
}
