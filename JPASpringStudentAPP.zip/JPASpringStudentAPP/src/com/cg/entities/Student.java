package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Student implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@SequenceGenerator(name="seq",sequenceName="seq_stu_id",
	allocationSize=1)
	@Column(name="stuid")
	private Long studentId;
	@NotEmpty(message="Please Enter Student FirstName")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Student First Name must contain only alphabets")
	@Column(name="first_name")
	private String firstName;
	@NotEmpty(message="Please Enter Student FirstName")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Student middle Name must contain only alphabets")
	@Column(name="middle_name")
	private String middleName;
	@NotEmpty(message="Please Enter Student FirstName")
	@Pattern(regexp = "^[a-zA-Z]+$", message = "Student Last Name must contain only alphabets")
	@Column(name="last_name")
	private String lastName;
	@NotEmpty(message="Please Select Branches")
	private String branches;
	@NotEmpty(message="Please Enter CollegeName")
	private String collegeName;
	
	
	
	public Long getStudentId() {
		return studentId;
	}
	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getBranches() {
		return branches;
	}
	public void setBranches(String branches) {
		this.branches = branches;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	
	
	
	

	
	
	
}
