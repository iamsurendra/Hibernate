package com.cg.service;

import java.util.List;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.StudentRepository;
import com.cg.entities.Student;

@Service
@Transactional	//This annotation will make automatic transaction management  
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;
	
	
	
	@Override
	public Student save(Student student) {
		return studentRepository.save(student);
	}
	
	
	@Override
	public List<Student> loadAll() {
		return studentRepository.loadAll();
	}

	@Override
	public Student getStudentsById(int id) {
		
		return studentRepository.getStudentsById(id);
	}
	
}
