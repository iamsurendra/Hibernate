package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;





import com.cg.entities.Student;
import com.cg.service.StudentService;


@Controller
public class StudentController {

	@Autowired
	private StudentService studentService;

	@RequestMapping("/index.obj")
	public String getHomePage(Model model){
		model.addAttribute("stuList",studentService.loadAll());
		model.addAttribute("branches",new String[]{"ECE","EEE","CSC","MECH","IT"});
		model.addAttribute("student",new Student());
		return "index";
	}

	@RequestMapping(value="/save.obj",method=RequestMethod.POST)
	public String saveStudent(@Valid @ModelAttribute("student") Student student,BindingResult result, Model model){
		int studentId=0;
		if (result.hasErrors()) {
			return "redirect:/index.obj";
		}
		
		try
		{
			student =  studentService.save(student);
		   model.addAttribute("message","Student with id "+student.getStudentId()+" added successfully!");
		}
		catch(DataAccessException dataAccessException)
		{
			model.addAttribute("msg","Technical Problem..Please Try Later!!");
			return "myError";
		}
		if (student != null) {
			model.addAttribute("studentId", studentId);
			model.addAttribute("branches", student.getBranches());
			return "addSuccess";
		} 
		else {
			String msg = "Technical Problem..Please Try Later!!";
			model.addAttribute("msg", msg);
			return "myError";
		}
		
		
	}
		
	}


