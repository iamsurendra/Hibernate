package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Student;
import com.cg.service.StudentService;

@Controller
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@RequestMapping("/index.obj")
	public String getHomePage(Model model){
		model.addAttribute("stdList",studentService.showAllStudents());
		model.addAttribute("department",new String[]{"CSE","ECE","ME","CE","EE"});
		model.addAttribute("student",new Student());
		model.addAttribute("find",new Student());
		model.addAttribute("delete", new Student());
		return "index";
	}
	
	@RequestMapping(value="/save.obj",method=RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("student") Student student, Model model){
		student =  studentService.save(student);
		model.addAttribute("message","student with id "+student.getId()+" added successfully!");
		return "redirect:/index.obj";
	}
	
	@RequestMapping(value="/findById.obj", method=RequestMethod.POST)
	public String findById(@ModelAttribute("find") Student student, Model model)
	{
			String details = studentService.findById(student.getId()).toString();
			System.out.println(details);
			model.addAttribute("findById", details);
			return "redirect:/index.obj";
	}
	
	@RequestMapping(value="/deleteStudent.obj", method=RequestMethod.POST)
	public String deleteStudent(@ModelAttribute("delete") Student student, Model model)
	{
		System.out.println("Here1");
		String delelteMsg = studentService.delete(student.getId()).toString();
		System.out.println(student);
		model.addAttribute("deleteById", delelteMsg);
		return "redirect:/index.obj";
	}
	
	@RequestMapping(value="/displayStudent.obj")
	public String nextPage(@RequestParam String id, Model model)
	{
		Student student = studentService.findById(Integer.parseInt(id));
		model.addAttribute("student", student);
		return "nextPage";
	}

}
