package com.cg.service;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.StudentRepository;
import com.cg.dao.StudentRepositoryImpl;
import com.cg.entities.Student;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentRepository repository;

	public StudentServiceImpl() {
		repository = new StudentRepositoryImpl(); 
	}

	@Override
	public Student save(Student student) {
		return repository.save(student);
	}

	@Override
	public List<Student> showAllStudents() {
		// TODO Auto-generated method stub
		return repository.showAllStudents();
	}

	@Override
	public Student findById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id);
	}

	@Override
	public Student delete(int id) {
		// TODO Auto-generated method stub
		return repository.delete(id);
	}

}
