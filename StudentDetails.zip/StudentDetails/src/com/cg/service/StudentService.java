package com.cg.service;

import java.util.List;

import com.cg.entities.Student;

public interface StudentService {
	
	public Student save(Student student);
	public List<Student> showAllStudents();
	public Student findById(int id);
	public Student delete(int id);
}
