package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.entities.Student;
import com.cg.service.StudentService;


@Controller
public class StudentController {
	
	@Autowired
	private StudentService stuService;

	@RequestMapping("/index.obj")
	public String getHomePage(Model model){
		model.addAttribute("stuList",stuService.loadAll());
		model.addAttribute("section",new String[]{"A","B","C","D"});
		model.addAttribute("student",new Student());
		return "index";
	}
	
	@RequestMapping(value="/save.obj",method=RequestMethod.POST)
	public String saveStudent(@ModelAttribute("student") @Valid Student student,BindingResult result, Model model)
	{
		if(result.hasErrors()){
			return "index";}
		
		else{
		student =  stuService.save(student);
		model.addAttribute("message","Student with id "+student.getsId()+" added successfully!");
		}
		return "redirect:/index.obj";
	}
	

}
