package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.StudentDao;
import com.cg.entities.Student;

@Service
@Transactional
public class StudentServiceImpl implements StudentService{
	@Autowired
	private StudentDao studentDao;
	
	@Override
	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		return studentDao.addStudent(student);
	}

	@Override
	public List<Student> showAll() {
		// TODO Auto-generated method stub
		return studentDao.showAll();
	}

	@Override
	public Student getStudentDetails(int studentId) {
		// TODO Auto-generated method stub
		return studentDao.getStudentDetails(studentId);
	}

	
}
