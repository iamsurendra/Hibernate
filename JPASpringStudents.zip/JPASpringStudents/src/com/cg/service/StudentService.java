package com.cg.service;

import java.util.List;

import com.cg.entities.Student;


public interface StudentService {
	public abstract Student addStudent(Student student);
	public  List<Student> showAll();
	
	public abstract Student getStudentDetails(int studentId);
}
