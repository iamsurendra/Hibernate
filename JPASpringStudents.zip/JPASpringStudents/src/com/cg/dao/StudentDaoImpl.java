package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Student;

@Repository
public class StudentDaoImpl implements StudentDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Student addStudent(Student student) {

		entityManager.persist(student);
		entityManager.flush();

		return student;
	}

	@Override
	public List<Student> showAll() {
		TypedQuery<Student> query = entityManager.createQuery("SELECT s FROM Student s",Student.class);
		return query.getResultList();

	}

	@Override
	public Student getStudentDetails(int studentId) {
		// TODO Auto-generated method stub
		Student student = entityManager.find(Student.class, studentId);
		return student;
	}

}
